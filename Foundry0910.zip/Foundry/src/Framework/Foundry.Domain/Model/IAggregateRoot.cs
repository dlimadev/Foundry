namespace Foundry.Domain.Model
{
    /// <summary>
    /// A marker interface for an Aggregate Root.
    /// </summary>
    public interface IAggregateRoot { }
}