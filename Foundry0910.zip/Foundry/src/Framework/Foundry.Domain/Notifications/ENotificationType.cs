namespace Foundry.Domain.Notifications
{
    public enum ENotificationType
    {
        Information,
        Warning,
        Error
    }
}