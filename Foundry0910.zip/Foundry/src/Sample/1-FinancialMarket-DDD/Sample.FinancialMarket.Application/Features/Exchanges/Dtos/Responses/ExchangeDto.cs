﻿namespace Sample.FinancialMarket.Application.Features.Exchanges.Dtos.Responses
{
    public record ExchangeDto(Guid Id, string Name, string Acronym, string Country);
}