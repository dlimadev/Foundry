﻿namespace Sample.FinancialMarket.Application.Features.Exchanges.Dtos.Requests
{
    public record UpdateExchangeRequest(string Name, string Country);
}