﻿// The code should be in English
using Castle.DynamicProxy;
using Foundry.Domain.Interfaces.Specifications;
using Foundry.Domain.Model;
using Foundry.Domain.Model.Attributes;
using Microsoft.Extensions.Caching.Distributed;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Foundry.Infrastructure.Interceptors
{
    /// <summary>
    /// An interceptor that adds a distributed caching layer to repository methods.
    /// It intercepts method calls, checks for the [Cacheable] attribute on the entity,
    /// and serves/stores data from/to the cache for read queries.
    /// </summary>
    public class CachingInterceptor : IAsyncInterceptor
    {
        private readonly IDistributedCache _cache;

        public CachingInterceptor(IDistributedCache cache)
        {
            _cache = cache;
        }

        public void InterceptSynchronous(IInvocation invocation)
        {
            // Caching is for async read operations, so we bypass sync calls.
            invocation.Proceed();
        }

        public void InterceptAsynchronous(IInvocation invocation)
        {
            invocation.ReturnValue = HandlePassthroughAsync(invocation);
        }

        public void InterceptAsynchronous<TResult>(IInvocation invocation)
        {
            invocation.ReturnValue = HandleCacheableMethodAsync<TResult>(invocation);
        }

        private async Task<TResult> HandleCacheableMethodAsync<TResult>(IInvocation invocation)
        {
            var entityType = GetEntityTypeFromInvocation(invocation);
            var cacheableAttribute = entityType?.GetCustomAttribute<CacheableAttribute>();

            // If the entity is not marked as [Cacheable], or if the method is not a read query, bypass caching.
            if (cacheableAttribute == null || !IsReadQuery(invocation.Method.Name))
            {
                invocation.Proceed();
                return await (Task<TResult>)invocation.ReturnValue;
            }

            var cacheKey = await GenerateCacheKey(entityType!, invocation);
            var cachedValue = await _cache.GetStringAsync(cacheKey);

            if (cachedValue != null)
            {
                // Cache Hit
                return JsonSerializer.Deserialize<TResult>(cachedValue)!;
            }

            // Cache Miss: proceed with the original method call.
            invocation.Proceed();
            var result = await (Task<TResult>)invocation.ReturnValue;

            if (result != null)
            {
                var options = new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(cacheableAttribute.DurationInMinutes) };
                await _cache.SetStringAsync(cacheKey, JsonSerializer.Serialize(result), options);
            }

            return result;
        }

        private async Task HandlePassthroughAsync(IInvocation invocation)
        {
            invocation.Proceed();
            await (Task)invocation.ReturnValue;
        }

        private bool IsReadQuery(string methodName) => methodName.StartsWith("Get") || methodName.StartsWith("List");

        private Type? GetEntityTypeFromInvocation(IInvocation invocation)
        {
            // For methods like IGenericRepository<TEntity>.GetByIdAsync(), TEntity is the generic argument.
            if (invocation.GenericArguments.Any())
            {
                return invocation.GenericArguments[0];
            }
            // For methods on specific repositories, we might need more advanced reflection.
            // This implementation assumes generic repository methods.
            var targetType = invocation.TargetType;
            var genericInterface = targetType.GetInterfaces().FirstOrDefault(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(Domain.Interfaces.Repositories.IGenericRepository<>));
            return genericInterface?.GetGenericArguments()[0];
        }

        private async Task<string> GenerateCacheKey(Type entityType, IInvocation invocation)
        {
            var entityTypeName = entityType.Name;

            // Handle GetByIdAsync
            if (invocation.Method.Name.Contains("GetById") && invocation.Arguments.Any())
            {
                return $"entity-{entityTypeName}-{invocation.Arguments[0]}";
            }

            // Handle ListAsync(ISpecification<T>)
            if (invocation.Method.Name.Contains("List") && invocation.Arguments.FirstOrDefault() is ISpecification<EntityBase> spec)
            {
                var listVersionKey = $"list-version-{entityTypeName}";
                var versionToken = await _cache.GetStringAsync(listVersionKey);
                if (string.IsNullOrEmpty(versionToken))
                {
                    versionToken = Guid.NewGuid().ToString();
                    await _cache.SetStringAsync(listVersionKey, versionToken);
                }

                var specString = new StringBuilder();
                specString.Append(spec.Criteria?.ToString() ?? "all");
                specString.Append(string.Join("-", spec.Includes.Select(i => i.ToString())));
                specString.Append(spec.OrderBy?.ToString() ?? "");
                specString.Append(spec.OrderByDescending?.ToString() ?? "");

                var keyMaterial = $"{listVersionKey}:{versionToken}:{specString}";
                using var sha256 = SHA256.Create();
                var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(keyMaterial));

                return $"list-{entityTypeName}-{Convert.ToBase64String(hashBytes)}";
            }

            return $"other-{entityTypeName}-{invocation.Method.Name}";
        }
    }
}