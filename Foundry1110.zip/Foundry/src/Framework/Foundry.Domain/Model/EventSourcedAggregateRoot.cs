// The code should be in English
using System.Collections.Generic;

namespace Foundry.Domain.Model
{
    public abstract class EventSourcedAggregateRoot : EntityBase, IAggregateRoot
    {
        public int CurrentVersion { get; protected set; }

        protected void ApplyAndStoreEvent(IDomainEvent domainEvent)
        {
            ((dynamic)this).Apply((dynamic)domainEvent);
            AddDomainEvent(domainEvent);
        }

        /// <summary>
        /// Rebuilds the aggregate's state from a historical sequence of events.
        /// This must be public to be called by the repository.
        /// </summary>
        public void LoadFromHistory(IEnumerable<IDomainEvent> history) // <-- CHANGED TO PUBLIC
        {
            foreach (var evt in history)
            {
                ((dynamic)this).Apply((dynamic)evt);
                CurrentVersion++;
            }
        }

        /// <summary>
        /// When implemented in a derived class, creates a snapshot of the aggregate's current state.
        /// This must be public to be called by the repository.
        /// </summary>
        public abstract IEventSourcedSnapshot CreateSnapshot(); // <-- CHANGED TO PUBLIC ABSTRACT

        /// <summary>
        /// When implemented in a derived class, restores the aggregate's state from a snapshot.
        /// This must be public to be called by the repository.
        /// </summary>
        public abstract void RestoreFromSnapshot(IEventSourcedSnapshot snapshot); // <-- CHANGED TO PUBLIC ABSTRACT
    }
}