﻿namespace Sample.FinancialMarket.Application.Features.Exchanges.Dtos.Requests
{
    public record CreateExchangeRequest(string Name, string Acronym, string Country);
}