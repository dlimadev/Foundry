using System.Collections.Generic;

namespace Foundry.Domain.Model
{
    /// <summary>
    /// An optional abstract base class for Aggregate Roots that are persisted using Event Sourcing.
    /// It provides the necessary infrastructure for rehydrating an aggregate from a stream of events.
    /// </summary>
    public abstract class EventSourcedAggregateRoot : EntityBase, IAggregateRoot
    {
        /// <summary>
        /// The current version of the aggregate after all events have been applied.
        /// </summary>
        public int CurrentVersion { get; protected set; }

        /// <summary>
        /// Applies an event to mutate the aggregate's state and adds it to the list of uncommitted domain events.
        /// </summary>
        /// <param name="domainEvent">The domain event to apply.</param>
        protected void ApplyAndStoreEvent(IDomainEvent domainEvent)
        {
            ((dynamic)this).Apply((dynamic)domainEvent);
            AddDomainEvent(domainEvent);
        }

        /// <summary>
        /// Rebuilds the aggregate's state from a historical sequence of events.
        /// </summary>
        /// <param name="history">The stream of past events for this aggregate.</param>
        public void LoadFromHistory(IEnumerable<IDomainEvent> history)
        {
            foreach (var evt in history)
            {
                ((dynamic)this).Apply((dynamic)evt);
                CurrentVersion++;
            }
        }

        /// <summary>
        /// When implemented in a derived class, creates a snapshot of the aggregate's current state.
        /// </summary>
        protected abstract IEventSourcedSnapshot CreateSnapshot();

        /// <summary>
        /// When implemented in a derived class, restores the aggregate's state from a snapshot.
        /// </summary>
        protected abstract void RestoreFromSnapshot(IEventSourcedSnapshot snapshot);
    }
}