using Foundry.Domain.Interfaces.Repositories;
using Foundry.Domain.Interfaces.Specifications;
using Foundry.Domain.Model;
using Microsoft.Extensions.Caching.Distributed;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Foundry.Infrastructure.Persistence.Repositories
{
    /// <summary>
    /// A Decorator for IGenericRepository that adds a distributed caching layer. It wraps another repository instance
    /// and intercepts read calls to check the cache first. It relies on domain events for cache invalidation.
    /// </summary>
    public class CachedGenericRepository<TEntity> : IGenericRepository<TEntity> where TEntity : EntityBase
    {
        private readonly IGenericRepository<TEntity> _decorated;
        private readonly IDistributedCache _cache;
        private readonly int _durationInMinutes;
        private readonly string _entityTypeName = typeof(TEntity).Name;

        public CachedGenericRepository(IGenericRepository<TEntity> decorated, IDistributedCache cache, int durationInMinutes)
        {
            _decorated = decorated;
            _cache = cache;
            _durationInMinutes = durationInMinutes;
        }
        
        /// <inheritdoc />
        public async Task<TEntity?> GetByIdAsync(Guid id)
        {
            string cacheKey = $"entity-{_entityTypeName}-{id}";
            var cachedValue = await _cache.GetStringAsync(cacheKey);

            if (cachedValue != null)
            {
                return JsonSerializer.Deserialize<TEntity>(cachedValue);
            }
            
            var entity = await _decorated.GetByIdAsync(id);

            if (entity != null)
            {
                var options = new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(_durationInMinutes) };
                await _cache.SetStringAsync(cacheKey, JsonSerializer.Serialize(entity), options);
            }
            return entity;
        }

        /// <inheritdoc />
        public async Task<IReadOnlyList<TEntity>> ListAsync(ISpecification<TEntity> spec)
        {
            string cacheKey = await GenerateCacheKeyFromSpec(spec);
            var cachedList = await _cache.GetStringAsync(cacheKey);

            if (cachedList != null)
            {
                return JsonSerializer.Deserialize<IReadOnlyList<TEntity>>(cachedList) ?? new List<TEntity>();
            }

            var entityList = await _decorated.ListAsync(spec);

            var options = new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(_durationInMinutes) };
            await _cache.SetStringAsync(cacheKey, JsonSerializer.Serialize(entityList), options);

            return entityList;
        }

        /// <summary>
        /// Generates a unique cache key from a specification, including a version token for invalidation.
        /// </summary>
        private async Task<string> GenerateCacheKeyFromSpec(ISpecification<TEntity> spec)
        {
            var listVersionKey = $"list-version-{_entityTypeName}";
            var versionToken = await _cache.GetStringAsync(listVersionKey);
            if (string.IsNullOrEmpty(versionToken))
            {
                versionToken = Guid.NewGuid().ToString();
                await _cache.SetStringAsync(listVersionKey, versionToken, new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24) });
            }

            var specString = new StringBuilder();
            specString.Append(spec.Criteria?.ToString() ?? "all");
            specString.Append(spec.OrderBy?.ToString() ?? "");
            specString.Append(spec.OrderByDescending?.ToString() ?? "");
            specString.Append(string.Join("-", spec.Includes.Select(i => i.ToString())));

            var keyMaterial = $"{listVersionKey}:{versionToken}:{specString}";
            using var sha256 = SHA256.Create();
            var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(keyMaterial));
            
            return $"list-{_entityTypeName}-{Convert.ToBase64String(hashBytes)}";
        }

        // --- Pass-through methods ---
        // Write methods just pass through. Invalidation is handled by the event handler.
        public Task AddAsync(TEntity entity) => _decorated.AddAsync(entity);
        public void Update(TEntity entity) => _decorated.Update(entity);
        public void Remove(TEntity entity) => _decorated.Remove(entity);
        
        // Other read methods pass through for this implementation.
        public Task<TEntity?> GetBySpecAsync(ISpecification<TEntity> spec) => _decorated.GetBySpecAsync(spec);
        public Task<IReadOnlyList<TEntity>> ListAllAsync() => _decorated.ListAllAsync();
        public Task<int> CountAsync(ISpecification<TEntity> spec) => _decorated.CountAsync(spec);
    }
}