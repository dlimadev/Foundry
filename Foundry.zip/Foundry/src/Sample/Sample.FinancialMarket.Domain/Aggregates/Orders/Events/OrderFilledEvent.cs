using Foundry.Domain.Model;
using System;

namespace Sample.FinancialMarket.Domain.Orders.Events
{
    public class OrderFilledEvent : IDomainEvent
    {
        public Guid OrderId { get; }
        public DateTime FilledDate { get; }
        public OrderFilledEvent(Guid orderId, DateTime filledDate)
        {
            OrderId = orderId;
            FilledDate = filledDate;
        }
    }
}