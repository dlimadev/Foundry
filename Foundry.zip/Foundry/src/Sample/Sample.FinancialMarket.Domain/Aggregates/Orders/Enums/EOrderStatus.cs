namespace Sample.FinancialMarket.Domain.Aggregates.Orders.Enums
{
    public enum EOrderStatus { Pending, Open, Filled, Cancelled }
}