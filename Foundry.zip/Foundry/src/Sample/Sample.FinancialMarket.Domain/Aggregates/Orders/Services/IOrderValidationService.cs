// The code should be in English
using Foundry.Domain.Notifications;
using Sample.FinancialMarket.Domain.Aggregates.Orders;
using System.Threading.Tasks;

namespace Sample.FinancialMarket.Domain.Orders.Services
{
    /// <summary>
    /// A Domain Service contract that defines the capability of validating an order.
    /// This abstraction allows the Order entity to trigger validation without being
    /// coupled to the specific validation implementation (like the Chain of Responsibility).
    /// </summary>
    public interface IOrderValidationService
    {
        /// <summary>
        /// Validates an order to ensure it can be opened.
        /// </summary>
        Task ValidateForOpening(Order order, INotificationHandler notifier);
    }
}