using Foundry.Domain.Interfaces.Repositories;
using Sample.FinancialMarket.Domain.Aggregates.Orders;

namespace Sample.FinancialMarket.Domain.Interfaces
{
    public interface IOrderRepository : IGenericRepository<Order> { }
}