﻿using Foundry.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Sample.FinancialMarket.Domain.Interfaces;
using Sample.FinancialMarket.Domain.Interfaces.Repositories;
using Sample.FinancialMarket.Infrastructure.Persistence;
using Sample.FinancialMarket.Infrastructure.Persistence.Repositories;

namespace Sample.FinancialMarket.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddSampleInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            // Register the concrete DbContext for EF Core migrations and the Unit of Work
            services.AddDbContext<FinanceDbContext>(options =>
                options.UseNpgsql(configuration.GetConnectionString("PostgresConnection")));

            // Bind the limited IApplicationDbContext interface to our concrete DbContext for the repositories
            services.AddScoped<IApplicationDbContext>(provider => provider.GetRequiredService<FinanceDbContext>());

            // Register this application's concrete repositories
            services.AddScoped<IOrderRepository, OrderRepository>();
            services.AddScoped<IPortfolioRepository, PortfolioRepository>();
            services.AddScoped<IStockRepository, StockRepository>();

            return services;
        }
    }
}